package view;

import controller.TelefoneController;
import modelo.Telefone;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class TelefoneView extends JFrame {
    private TelefoneController telefoneController = new TelefoneController();

    private JTextField txtNumero, txtId;
    private JButton btnSalvar, btnListar, btnDeletar;

    public TelefoneView() {
        setTitle("Gerenciar Telefones");
        setSize(350, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2));

        panel.add(new JLabel("Número:"));
        txtNumero = new JTextField();
        panel.add(txtNumero);

        btnSalvar = new JButton("Salvar");
        btnSalvar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                salvarTelefone();
            }
        });
        panel.add(btnSalvar);

        btnListar = new JButton("Listar Telefones");
        btnListar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                listarTelefones();
            }
        });
        panel.add(btnListar);

        panel.add(new JLabel("ID (para deletar):"));
        txtId = new JTextField();
        panel.add(txtId);

        btnDeletar = new JButton("Deletar");
        btnDeletar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deletarTelefone();
            }
        });
        panel.add(btnDeletar);

        add(panel);
        setVisible(true);
    }

    private void salvarTelefone() {
        Telefone telefone = new Telefone();
        telefone.setNumero(txtNumero.getText());
        telefoneController.adicionarTelefone(telefone);
        JOptionPane.showMessageDialog(this, "Telefone salvo com sucesso!");
        txtNumero.setText("");
    }

    private void listarTelefones() {
        List<Telefone> telefones = telefoneController.listarTelefones();
        StringBuilder sb = new StringBuilder();
        for (Telefone telefone : telefones) {
            sb.append("ID: ").append(telefone.getId()).append(", Número: ").append(telefone.getNumero()).append("\n");
        }
        JOptionPane.showMessageDialog(this, sb.toString(), "Lista de Telefones", JOptionPane.INFORMATION_MESSAGE);
    }

    private void deletarTelefone() {
        try {
            Long id = Long.parseLong(txtId.getText());
            telefoneController.deletarTelefone(id);
            JOptionPane.showMessageDialog(this, "Telefone deletado com sucesso!");
            txtId.setText("");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID inválido!", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(TelefoneView::new);
    }
}
