package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class MainView extends JFrame {
    
    public final Pattern VALID_EMAIL_ADDRESS_REGEX = 
    Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);

    
    public boolean validate(String emailStr) {
        Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(emailStr);
        return matcher.matches();
}
    public MainView() {
        
        System.out.println("mensagem" + validate("a@a."));
       
        
        
        setTitle("Agenda de Contatos");
        setSize(400, 300); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 1, 10, 10)); 
        
        
        ImageIcon contactsIcon = createImageIcon("/icons/contacts.png");
        ImageIcon usersIcon = createImageIcon("/icons/users.png");
        ImageIcon addressesIcon = createImageIcon("/icons/addresses.png");
        ImageIcon phonesIcon = createImageIcon("/icons/phones.png");
        ImageIcon professionsIcon = createImageIcon("/icons/professions.png");

        JButton btnContatos = new JButton("Gerenciar Contatos", contactsIcon);
        JButton btnUsuarios = new JButton("Gerenciar Usuários", usersIcon);
        JButton btnEnderecos = new JButton("Gerenciar Endereços", addressesIcon);
        JButton btnTelefones = new JButton("Gerenciar Telefones", phonesIcon);
        JButton btnProfissoes = new JButton("Gerenciar Profissões", professionsIcon);

        
        btnContatos.setVerticalTextPosition(AbstractButton.BOTTOM);
        btnContatos.setHorizontalTextPosition(AbstractButton.CENTER);
        btnUsuarios.setVerticalTextPosition(AbstractButton.BOTTOM);
        btnUsuarios.setHorizontalTextPosition(AbstractButton.CENTER);
        btnEnderecos.setVerticalTextPosition(AbstractButton.BOTTOM);
        btnEnderecos.setHorizontalTextPosition(AbstractButton.CENTER);
        btnTelefones.setVerticalTextPosition(AbstractButton.BOTTOM);
        btnTelefones.setHorizontalTextPosition(AbstractButton.CENTER);
        btnProfissoes.setVerticalTextPosition(AbstractButton.BOTTOM);
        btnProfissoes.setHorizontalTextPosition(AbstractButton.CENTER);

        
        btnContatos.addActionListener(e -> new ContatoView());
        btnUsuarios.addActionListener(e -> new UsuarioView());
        btnEnderecos.addActionListener(e -> new EnderecoView());
        btnTelefones.addActionListener(e -> new TelefoneView());
        btnProfissoes.addActionListener(e -> new ProfissaoView());

        panel.add(btnContatos);
        panel.add(btnUsuarios);
        panel.add(btnEnderecos);
        panel.add(btnTelefones);
        panel.add(btnProfissoes);

        
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); 
        panel.setBackground(Color.WHITE); 

        add(panel);
        setVisible(true);
    }

    private ImageIcon createImageIcon(String path) {
        java.net.URL imgURL = getClass().getResource(path);
        if (imgURL != null) {
            return new ImageIcon(imgURL);
        } else {
            System.err.println("Couldn't find file: " + path);
            return null;
        }
    }

    public static void main(String[] args) {
        
        SwingUtilities.invokeLater(MainView::new);
    }
}
