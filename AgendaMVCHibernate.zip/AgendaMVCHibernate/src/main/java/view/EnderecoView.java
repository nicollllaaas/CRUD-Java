package view;

import controller.EnderecoController;
import modelo.Endereco;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class EnderecoView extends JFrame {
    private EnderecoController enderecoController = new EnderecoController();

    private JTextField txtRua, txtCidade, txtEstado, txtId;
    private JButton btnSalvar, btnListar, btnDeletar;

    public EnderecoView() {
        setTitle("Gerenciar Endereços");
        setSize(350, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 2));

        panel.add(new JLabel("Rua:"));
        txtRua = new JTextField();
        panel.add(txtRua);

        panel.add(new JLabel("Cidade:"));
        txtCidade = new JTextField();
        panel.add(txtCidade);

        panel.add(new JLabel("Estado:"));
        txtEstado = new JTextField();
        panel.add(txtEstado);

        btnSalvar = new JButton("Salvar");
        btnSalvar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                salvarEndereco();
            }
        });
        panel.add(btnSalvar);

        btnListar = new JButton("Listar Endereços");
        btnListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                listarEnderecos();
            }
        });
        panel.add(btnListar);

        panel.add(new JLabel("ID (para deletar):"));
        txtId = new JTextField();
        panel.add(txtId);

        btnDeletar = new JButton("Deletar");
        btnDeletar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deletarEndereco();
            }
        });
        panel.add(btnDeletar);

        add(panel);
        setVisible(true);
    }

    private void salvarEndereco() {
        Endereco endereco = new Endereco();
        endereco.setRua(txtRua.getText());
        endereco.setCidade(txtCidade.getText());
        endereco.setEstado(txtEstado.getText());
        enderecoController.adicionarEndereco(endereco);
        JOptionPane.showMessageDialog(this, "Endereço salvo com sucesso!");
        txtRua.setText("");
        txtCidade.setText("");
        txtEstado.setText("");
    }

    private void listarEnderecos() {
        List<Endereco> enderecos = enderecoController.listarEnderecos();
        StringBuilder sb = new StringBuilder();
        for (Endereco endereco : enderecos) {
            sb.append("ID: ").append(endereco.getId()).append(", Rua: ").append(endereco.getRua())
              .append(", Cidade: ").append(endereco.getCidade()).append(", Estado: ").append(endereco.getEstado()).append("\n");
        }
        JOptionPane.showMessageDialog(this, sb.toString(), "Lista de Endereços", JOptionPane.INFORMATION_MESSAGE);
    }

    private void deletarEndereco() {
        try {
            Long id = Long.parseLong(txtId.getText());
            enderecoController.deletarEndereco(id);
            JOptionPane.showMessageDialog(this, "Endereço deletado com sucesso!");
            txtId.setText("");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID inválido!", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(EnderecoView::new);
    }
}
