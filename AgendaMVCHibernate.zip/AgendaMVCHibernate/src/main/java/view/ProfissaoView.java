package view;

import controller.ProfissaoController;
import modelo.Profissao;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ProfissaoView extends JFrame {
    private ProfissaoController profissaoController = new ProfissaoController();

    private JTextField txtNome, txtId;
    private JButton btnSalvar, btnListar, btnDeletar;

    public ProfissaoView() {
        setTitle("Gerenciar Profissões");
        setSize(350, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2));

        panel.add(new JLabel("Nome:"));
        txtNome = new JTextField();
        panel.add(txtNome);

        btnSalvar = new JButton("Salvar");
        btnSalvar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                salvarProfissao();
            }
        });
        panel.add(btnSalvar);

        btnListar = new JButton("Listar Profissões");
        btnListar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                listarProfissoes();
            }
        });
        panel.add(btnListar);

        panel.add(new JLabel("ID (para deletar):"));
        txtId = new JTextField();
        panel.add(txtId);

        btnDeletar = new JButton("Deletar");
        btnDeletar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deletarProfissao();
            }
        });
        panel.add(btnDeletar);

        add(panel);
        setVisible(true);
    }

    private void salvarProfissao() {
        Profissao profissao = new Profissao();
        profissao.setNome(txtNome.getText());
        profissaoController.adicionarProfissao(profissao);
        JOptionPane.showMessageDialog(this, "Profissão salva com sucesso!");
        txtNome.setText("");
    }

    private void listarProfissoes() {
        List<Profissao> profissoes = profissaoController.listarProfissoes();
        StringBuilder sb = new StringBuilder();
        for (Profissao profissao : profissoes) {
            sb.append("ID: ").append(profissao.getId()).append(", Nome: ").append(profissao.getNome()).append("\n");
        }
        JOptionPane.showMessageDialog(this, sb.toString(), "Lista de Profissões", JOptionPane.INFORMATION_MESSAGE);
    }

    private void deletarProfissao() {
        try {
            Long id = Long.parseLong(txtId.getText());
            profissaoController.deletarProfissao(id);
            JOptionPane.showMessageDialog(this, "Profissão deletada com sucesso!");
            txtId.setText("");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID inválido!", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ProfissaoView::new);
    }
}
